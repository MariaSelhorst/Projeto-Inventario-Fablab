const express = require('express');
const router = express.Router();
const db = require('../database');

router.get('/', (req, res) => {
    db.all("SELECT * FROM itens", [], (err, rows) => res.json(rows));
});

router.post('/', (req, res) => {
    const { nome, categoria, quantidade, localizacao } = req.body;

    db.run(
        "INSERT INTO itens (nome, categoria, quantidade, localizacao) VALUES (?, ?, ?, ?)",
        [nome, categoria, quantidade, localizacao],
        function () {
            res.json({ id: this.lastID });
        }
    );
});

router.delete('/:id', (req, res) => {
    db.run("DELETE FROM itens WHERE id=?", [req.params.id], () => res.json({ ok: true }));
});

module.exports = router;